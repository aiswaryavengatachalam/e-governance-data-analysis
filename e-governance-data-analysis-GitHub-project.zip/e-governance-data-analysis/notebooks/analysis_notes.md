# Analysis Notes

1. Load the dataset with Pandas.
2. Check dimensions, data types and missing values.
3. Validate KPI definitions.
4. Calculate year-wise summary statistics.
5. Visualize service availability and completion rate.
6. For the later internship stage, replace the demonstration data with documented official public datasets.
7. Record source URL, reporting period and access date for every official dataset.
