import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data" / "sample_e_governance_data.csv"
OUT = BASE / "visualizations"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)

print("Dataset shape:", df.shape)
print("\nColumns:")
print(df.columns.tolist())
print("\nMissing values:")
print(df.isna().sum())

summary = (
    df.groupby("Year", as_index=False)
      .agg(
          Total_Services=("Services_Available", "sum"),
          Total_Applications=("Applications_or_Transactions", "sum"),
          Average_Completion_Rate=("Completion_Rate", "mean"),
          Average_Processing_Days=("Avg_Processing_Days", "mean")
      )
)
print("\nYear-wise summary:")
print(summary)

plt.figure(figsize=(8, 5))
plt.bar(summary["Year"].astype(str), summary["Total_Services"])
plt.title("Total Services by Year")
plt.xlabel("Year")
plt.ylabel("Number of Services")
plt.tight_layout()
plt.savefig(OUT / "service_availability.png", dpi=150)
plt.close()

plt.figure(figsize=(8, 5))
plt.plot(summary["Year"], summary["Average_Completion_Rate"], marker="o")
plt.title("Average Completion Rate by Year")
plt.xlabel("Year")
plt.ylabel("Completion Rate")
plt.ylim(0, 1)
plt.tight_layout()
plt.savefig(OUT / "completion_rate.png", dpi=150)
plt.close()

print("\nCharts saved in:", OUT)
